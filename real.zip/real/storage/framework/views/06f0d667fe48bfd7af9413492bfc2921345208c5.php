

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('img/bg.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
           
        }

    </style>
</head>

<body>
   
    </div>

    <!-- Form Start -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Add Property</h5>
                        <form action="submit_property.php" method="POST">
                            <div class="mb-3">
                                <label for="location" class="form-label">Home Location</label>
                                <input type="text" class="form-control" id="location" name="location" required>
                            </div>
                            <div class="mb-3">
                                <label for="bedrooms" class="form-label">Number of Bedrooms</label>
                                <input type="number" class="form-control" id="bedrooms" name="bedrooms" required>
                            </div>
                            <div class="mb-3">
                                <label for="bathrooms" class="form-label">Number of Bathrooms</label>
                                <input type="number" class="form-control" id="bathrooms" name="bathrooms" required>
                            </div>
                            <div class="mb-3">
                                <label for="price" class="form-label">Home Price</label>
                                <input type="number" class="form-control" id="price" name="price" required>
                            </div>
                            <div class="mb-3">
                                <label for="floor" class="form-label">Floor</label>
                                <input type="text" class="form-control" id="floor" name="floor" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Form End -->

  
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate\resources\views/add.blade.php ENDPATH**/ ?>