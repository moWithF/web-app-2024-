<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>signup Page</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
      rel="stylesheet"
    />

    <!-- Icon Font Stylesheet -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
      rel="stylesheet"
    />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet" />
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <link href="css/style.css" rel="stylesheet" />

  </head>

  <body>
     <!-- Navbar Start -->
     <div class="container-xxl bg-white p-0">
         <div class="container-fluid nav-bar bg-transparent">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
          <a
            href="index.blade.php"
            class="navbar-brand d-flex align-items-center text-center"
          >
            <div class="icon p-2 me-2">
              <img
                class="img-fluid"
                src="img/icon-deal.png"
                alt="Icon"
                style="width: 30px; height: 30px"
              />
            </div>
            <h1 class="m-0 text-primary">Real-Estate</h1>
          </a>

          <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto">
              <a href="index" class="nav-item nav-link ">Home</a>
              <a href="signup" class="nav-item nav-link active ">signup</a>
              <a href="about" class="nav-item nav-link">About</a>
              <a href="property-list" class="nav-item nav-link ">Property List</a>
              <a href="contact" class="nav-item nav-link">Contact</a>
              
            </div>

            <a href="add" class="btn btn-primary px-3 d-none d-lg-flex"
              >Add Property</a
            >
          </div>
        </nav>
      </div>
      <!-- Navbar End -->

    

      <div class="container">
        <div class="row">
          <div class="col-md-6 offset-md-3 form-container">
            <h2 class="text-center">Sign up</h2>
            <form action="signup.php" method="POST">
              <div class="form-group">
                <label for="first-name">First Name</label>
                <input
                  type="text"
                  class="form-control"
                  id="first-name"
                  name="first-name"
                  required
                />
              </div>
              <div class="form-group">
                <label for="last-name">Last Name</label>
                <input
                  type="text"
                  class="form-control"
                  id="last-name"
                  name="last-name"
                  required
                />
              </div>
              <div class="form-group">
                <label for="email">Email address</label>
                <input
                  type="email"
                  class="form-control"
                  id="email"
                  name="email"
                  required
                />
              </div>
              <div class="form-group">
                <label for="phone">Phone</label>
                <input
                  type="tel"
                  class="form-control"
                  id="phone"
                  name="phone"
                  required
                />
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input
                  type="password"
                  class="form-control"
                  id="password"
                  name="password"
                  required
                />
              </div>
              <button type="submit" class="btn btn-primary btn-block mt-3">
                Sign Up
              </button>
            </form>

           
            </p>
          </div>
        </div>
      </div>

      <!-- Back to Top -->
      <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"
        ><i class="bi bi-arrow-up"></i
      ></a>
    </div>
  </body>
</html>
<?php /**PATH C:\wamp64\www\real-estate\resources\views/signup.blade.php ENDPATH**/ ?>