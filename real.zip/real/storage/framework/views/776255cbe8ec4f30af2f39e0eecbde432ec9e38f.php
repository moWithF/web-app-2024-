

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('img/bg.jpeg');
            background-size: cover;
            background-position: center;
            height: 100vh;
           
        }

    </style>
</head>

<body>
   
    </div>

    <!-- Form Start -->
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('add your apartment details for sale')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('property-list')); ?>">
                        <?php echo csrf_field(); ?>

                        <!-- home_space Field -->
                        <div class="mb-3 row">
                            <label for="home_space" class="col-md-4 col-form-label text-md-end"><?php echo e(__('House space')); ?></label>
                            <div class="col-md-6">
                                <input id="home_space" type="number" class="form-control <?php $__errorArgs = ['home_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="home_space" value="<?php echo e(old('home_space')); ?>" required autocomplete="home_space" autofocus>
                                <?php $__errorArgs = ['home_space'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- floor -->
                        <div class="mb-3 row">
                            <label for="floor" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Floor')); ?></label>
                            <div class="col-md-6">
                                <input id="floor" type="number" class="form-control <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="floor" value="<?php echo e(old('floor')); ?>" required autofocus>
                                <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- home_price Field -->
                        <div class="mb-3 row">
                            <label for="home_price" class="col-md-4 col-form-label text-md-end"><?php echo e(__('House price ')); ?></label>
                            <div class="col-md-6">
                                <input id="home_price" type="number" class="form-control <?php $__errorArgs = ['home_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="home_price" value="<?php echo e(old('home_price')); ?>" required autocomplete="home_price">
                                <?php $__errorArgs = ['home_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- num_of_bathrooms -->
                        <div class="mb-3 row">
                            <label for="num_of_bathrooms" class="col-md-4 col-form-label text-md-end"><?php echo e(__('number of bathrooms')); ?></label>
                            <div class="col-md-6">
                                <input id="num_of_bathrooms" type="number" class="form-control <?php $__errorArgs = ['num_of_bathrooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="num_of_bathrooms" required autocomplete="new-num_of_bathrooms">
                                <?php $__errorArgs = ['num_of_bathrooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Confirm Password Field -->
                        <div class="mb-3 row">
                            <label for="num_of_bedrooms" class="col-md-4 col-form-label text-md-end"><?php echo e(__('number of bedrooms')); ?></label>
                            <div class="col-md-6">
                                <input id="num_of_bedrooms" type="number" class="form-control" name="num_of_bedrooms" required autocomplete="num_of_bedrooms">
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="location" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Address')); ?></label>
                            <div class="col-md-6">
                                <input id="location" type="number" class="form-control" name="location" required autocomplete="location">
                            </div>
                        </div>

                        <!-- Register Button -->
                        <div class="mb-0 row">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('submit')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Form End -->

  
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\real-estate\resources\views/appartment.blade.php ENDPATH**/ ?>