<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Makaan - Real Estate HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
      rel="stylesheet"
    />

    <!-- Icon Font Stylesheet -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
      rel="stylesheet"
    />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet" />
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <style>
      /********** Template CSS **********/
      :root {
        --primary: #00b98e;
        --secondary: #ff6922;
        --light: #effdf5;
        --dark: #0e2e50;
      }

      .back-to-top {
        position: fixed;
        display: none;
        right: 45px;
        bottom: 45px;
        z-index: 99;
      }

      /*** Spinner ***/
      #spinner {
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.5s ease-out, visibility 0s linear 0.5s;
        z-index: 99999;
      }

      #spinner.show {
        transition: opacity 0.5s ease-out, visibility 0s linear 0s;
        visibility: visible;
        opacity: 1;
      }

      /*** Button ***/
      .btn {
        transition: 0.5s;
      }

      .btn.btn-primary,
      .btn.btn-secondary {
        color: #ffffff;
      }

      .btn-square {
        width: 38px;
        height: 38px;
      }

      .btn-sm-square {
        width: 32px;
        height: 32px;
      }

      .btn-lg-square {
        width: 48px;
        height: 48px;
      }

      .btn-square,
      .btn-sm-square,
      .btn-lg-square {
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: normal;
        border-radius: 50px;
      }

      /*** Navbar ***/
      .nav-bar {
        position: relative;
        margin-top: 45px;
        padding: 0 3rem;
        transition: 0.5s;
        z-index: 9999;
      }

      .nav-bar.sticky-top {
        position: sticky;
        padding: 0;
        z-index: 9999;
      }

      .navbar {
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.08);
      }

      .navbar .dropdown-toggle::after {
        border: none;
        content: "\f107";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        vertical-align: middle;
        margin-left: 5px;
        transition: 0.5s;
      }

      .navbar .dropdown-toggle[aria-expanded="true"]::after {
        transform: rotate(-180deg);
      }

      .navbar-light .navbar-nav .nav-link {
        margin-right: 30px;
        padding: 25px 0;
        color: #ffffff;
        font-size: 15px;
        text-transform: uppercase;
        outline: none;
      }

      .navbar-light .navbar-nav .nav-link:hover,
      .navbar-light .navbar-nav .nav-link.active {
        color: var(--primary);
      }

      @media (max-width: 991.98px) {
        .nav-bar {
          margin: 0;
          padding: 0;
        }

        .navbar-light .navbar-nav .nav-link {
          margin-right: 0;
          padding: 10px 0;
        }

        .navbar-light .navbar-nav {
          border-top: 1px solid #eeeeee;
        }
      }

      .navbar-light .navbar-brand {
        height: 75px;
      }

      .navbar-light .navbar-nav .nav-link {
        color: var(--dark);
        font-weight: 500;
      }

      @media (min-width: 992px) {
        .navbar .nav-item .dropdown-menu {
          display: block;
          top: 100%;
          margin-top: 0;
          transform: rotateX(-75deg);
          transform-origin: 0% 0%;
          opacity: 0;
          visibility: hidden;
          transition: 0.5s;
        }

        .navbar .nav-item:hover .dropdown-menu {
          transform: rotateX(0deg);
          visibility: visible;
          transition: 0.5s;
          opacity: 1;
        }
      }

      /*** Header ***/
      @media (min-width: 992px) {
        .header {
          margin-top: -120px;
        }
      }

      .header-carousel .owl-nav {
        position: absolute;
        top: 50%;
        left: -25px;
        transform: translateY(-50%);
        display: flex;
        flex-direction: column;
      }

      .header-carousel .owl-nav .owl-prev,
      .header-carousel .owl-nav .owl-next {
        margin: 7px 0;
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        background: var(--primary);
        border-radius: 40px;
        font-size: 20px;
        transition: 0.5s;
      }

      .header-carousel .owl-nav .owl-prev:hover,
      .header-carousel .owl-nav .owl-next:hover {
        background: var(--dark);
      }

      @media (max-width: 768px) {
        .header-carousel .owl-nav {
          left: 25px;
        }
      }

      .breadcrumb-item + .breadcrumb-item::before {
        color: #dddddd;
      }

      /*** Icon ***/
      .icon {
        padding: 15px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #ffffff !important;
        border-radius: 50px;
        border: 1px dashed var(--primary) !important;
      }

      /*** About ***/
      .about-img img {
        position: relative;
        z-index: 2;
      }

      .about-img::before {
        position: absolute;
        content: "";
        top: 0;
        left: -50%;
        width: 100%;
        height: 100%;
        background: var(--primary);
        transform: skew(20deg);
        z-index: 1;
      }

      /*** Category ***/
      .cat-item div {
        background: #ffffff;
        border: 1px dashed rgba(0, 185, 142, 0.3);
        transition: 0.5s;
      }

      .cat-item:hover div {
        background: var(--primary);
        border-color: transparent;
      }

      .cat-item div * {
        transition: 0.5s;
      }

      .cat-item:hover div * {
        color: #ffffff !important;
      }

      /*** Property List ***/
      .nav-pills .nav-item .btn {
        color: var(--dark);
      }

      .nav-pills .nav-item .btn:hover,
      .nav-pills .nav-item .btn.active {
        color: #ffffff;
      }

      .property-item {
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.08);
      }

      .property-item img {
        transition: 0.5s;
      }

      .property-item:hover img {
        transform: scale(1.1);
      }

      .property-item .border-top {
        border-top: 1px dashed rgba(0, 185, 142, 0.3) !important;
      }

      .property-item .border-end {
        border-right: 1px dashed rgba(0, 185, 142, 0.3) !important;
      }

      /*** Team ***/
      .team-item {
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.08);
        transition: 0.5s;
      }

      .team-item .btn {
        color: var(--primary);
        background: #ffffff;
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.15);
      }

      .team-item .btn:hover {
        color: #ffffff;
        background: var(--primary);
      }

      .team-item:hover {
        border-color: var(--secondary) !important;
      }

      .team-item:hover .bg-primary {
        background: var(--secondary) !important;
      }

      .team-item:hover .bg-primary i {
        color: var(--secondary) !important;
      }

      /*** Testimonial ***/
      .testimonial-carousel {
        padding-left: 1.5rem;
        padding-right: 1.5rem;
      }

      @media (min-width: 576px) {
        .testimonial-carousel {
          padding-left: 4rem;
          padding-right: 4rem;
        }
      }

      .testimonial-carousel .testimonial-item .border {
        border: 1px dashed rgba(0, 185, 142, 0.3) !important;
      }

      .testimonial-carousel .owl-nav {
        position: absolute;
        width: 100%;
        height: 40px;
        top: calc(50% - 20px);
        left: 0;
        display: flex;
        justify-content: space-between;
        z-index: 1;
      }

      .testimonial-carousel .owl-nav .owl-prev,
      .testimonial-carousel .owl-nav .owl-next {
        position: relative;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        background: var(--primary);
        border-radius: 40px;
        font-size: 20px;
        transition: 0.5s;
      }

      .testimonial-carousel .owl-nav .owl-prev:hover,
      .testimonial-carousel .owl-nav .owl-next:hover {
        background: var(--dark);
      }

      /*** Footer ***/
      .footer .btn.btn-social {
        margin-right: 5px;
        width: 35px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--light);
        border: 1px solid rgba(255, 255, 255, 0.5);
        border-radius: 35px;
        transition: 0.3s;
      }

      .footer .btn.btn-social:hover {
        color: var(--primary);
        border-color: var(--light);
      }

      .footer .btn.btn-link {
        display: block;
        margin-bottom: 5px;
        padding: 0;
        text-align: left;
        font-size: 15px;
        font-weight: normal;
        text-transform: capitalize;
        transition: 0.3s;
      }

      .footer .btn.btn-link::before {
        position: relative;
        content: "\f105";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        margin-right: 10px;
      }

      .footer .btn.btn-link:hover {
        letter-spacing: 1px;
        box-shadow: none;
      }

      .footer .form-control {
        border-color: rgba(255, 255, 255, 0.5);
      }

      .footer .copyright {
        padding: 25px 0;
        font-size: 15px;
        border-top: 1px solid rgba(256, 256, 256, 0.1);
      }

      .footer .copyright a {
        color: var(--light);
      }

      .footer .footer-menu a {
        margin-right: 15px;
        padding-right: 15px;
        border-right: 1px solid rgba(255, 255, 255, 0.1);
      }

      .footer .footer-menu a:last-child {
        margin-right: 0;
        padding-right: 0;
        border-right: none;
      }
    </style>
  </head>

  <body>
    <div class="container-xxl bg-white p-0">
      <!-- Navbar Start -->
        <!-- Navbar Start -->
        <div class="container-fluid nav-bar bg-transparent">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
          <a
            href="index.blade.php"
            class="navbar-brand d-flex align-items-center text-center"
          >
            <div class="icon p-2 me-2">
              <img
                class="img-fluid"
                src="img/icon-deal.png"
                alt="Icon"
                style="width: 30px; height: 30px"
              />
            </div>
            <h1 class="m-0 text-primary">Makaan</h1>
          </a>
          <button
            type="button"
            class="navbar-toggler"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto">
              <a href="index" class="nav-item nav-link ">Home</a>
              <a href="signup" class="nav-item nav-link">signup</a>
              <a href="about" class="nav-item nav-link">About</a>
              <div class="nav-item dropdown">
                <a
                  href="#"
                  class="nav-link dropdown-toggle"
                  data-bs-toggle="dropdown"
                  >Property</a
                >
                <div class="dropdown-menu rounded-0 m-0">
                  <a href="property-list" class="dropdown-item"
                    >Property List</a
                  >
                  <a href="property-type" class="dropdown-item"
                    >Property Type</a
                  >
                  <a href="property-agent" class="dropdown-item active "
                    >Property Agent</a
                  >
                </div>
              </div>
              <div class="nav-item dropdown">
                <a
                  href="#"
                  class="nav-link dropdown-toggle"
                  data-bs-toggle="dropdown"
                  >Pages</a
                >
                <div class="dropdown-menu rounded-0 m-0">
                  <a href="testimonial" class="dropdown-item"
                    >Testimonial</a
                  >
                  <a href="404" class="dropdown-item">404 Error</a>
                </div>
              </div>
              <a href="contact" class="nav-item nav-link">Contact</a>
            </div>
            <a href="" class="btn btn-primary px-3 d-none d-lg-flex"
              >Add Property</a
            >
          </div>
        </nav>
      </div>
      <!-- Navbar End -->
      <!-- Navbar End -->

      <!-- Header Start -->
      <div class="container-fluid header bg-white p-0">
        <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
          <div class="col-md-6 p-5 mt-lg-5">
            <h1 class="display-5 animated fadeIn mb-4">Property Agent</h1>
            <nav aria-label="breadcrumb animated fadeIn">
              <ol class="breadcrumb text-uppercase">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li
                  class="breadcrumb-item text-body active"
                  aria-current="page"
                >
                  Property Agent
                </li>
              </ol>
            </nav>
          </div>
          <div class="col-md-6 animated fadeIn">
            <img class="img-fluid" src="img/header.jpg" alt="" />
          </div>
        </div>
      </div>
      <!-- Header End -->

      <!-- Search Start -->
      <div
        class="container-fluid bg-primary mb-5 wow fadeIn"
        data-wow-delay="0.1s"
        style="padding: 35px"
      >
        <div class="container">
          <div class="row g-2">
            <div class="col-md-10">
              <div class="row g-2">
                <div class="col-md-4">
                  <input
                    type="text"
                    class="form-control border-0 py-3"
                    placeholder="Search Keyword"
                  />
                </div>
                <div class="col-md-4">
                  <select class="form-select border-0 py-3">
                    <option selected>Property Type</option>
                    <option value="1">Property Type 1</option>
                    <option value="2">Property Type 2</option>
                    <option value="3">Property Type 3</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <select class="form-select border-0 py-3">
                    <option selected>Location</option>
                    <option value="1">Location 1</option>
                    <option value="2">Location 2</option>
                    <option value="3">Location 3</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <button class="btn btn-dark border-0 w-100 py-3">Search</button>
            </div>
          </div>
        </div>
      </div>
      <!-- Search End -->

      <!-- Team Start -->
      <div class="container-xxl py-5">
        <div class="container">
          <div
            class="text-center mx-auto mb-5 wow fadeInUp"
            data-wow-delay="0.1s"
            style="max-width: 600px"
          >
            <h1 class="mb-3">Property Agents</h1>
            <p>
            Meet our Property Agents, the navigators of your real estate journey. With expertise as their compass and dedication as their fuel, they guide you through the maze of listings, helping you find your perfect home sweet home. From dreamy abodes to lucrative investments, they're your trusted allies, making every step of the process smooth sailing. Let our Property Agents be the wind beneath your wings as you soar towards your property dreams.</p>
          </div>
          <div class="row g-4">
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
              <div class="team-item rounded overflow-hidden">
                <div class="position-relative">
                  <img class="img-fluid" src="img/essam.jpg"  style="height: 400px;"   alt="" />
                  <div
                    class="position-absolute start-50 top-100 translate-middle d-flex align-items-center"
                  >
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-facebook-f"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-instagram"></i
                    ></a>
                  </div>
                </div>
                <div class="text-center p-4 mt-3">
                  <h5 class="fw-bold mb-0">Essam Alaa Eldin</h5>
                  <p>Team leader</p>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
              <div class="team-item rounded overflow-hidden">
                <div class="position-relative">
                  <img class="img-fluid" src="img/omar.jpg" alt="" />
                  <div
                    class="position-absolute start-50 top-100 translate-middle d-flex align-items-center"
                  >
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-facebook-f"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-instagram"></i
                    ></a>
                  </div>
                </div>
                <div class="text-center p-4 mt-3">
                  <h5 class="fw-bold mb-0">Omar Osama</h5>
                  <p>Front-end developer</p>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
              <div class="team-item rounded overflow-hidden">
                <div class="position-relative">
                  <img class="img-fluid" src="img/mohamed.jpg" alt="" />
                  <div
                    class="position-absolute start-50 top-100 translate-middle d-flex align-items-center"
                  >
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-facebook-f"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-instagram"></i
                    ></a>
                  </div>
                </div>
                <div class="text-center p-4 mt-3">
                  <h5 class="fw-bold mb-0">Mohamed Firas</h5>
                  <p> UI/UX designer </p>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
              <div class="team-item rounded overflow-hidden">
                <div class="position-relative">
                  <img class="img-fluid" src="img/khaled.jpg" style="height: 400px;" alt="" />
                  <div
                    class="position-absolute start-50 top-100 translate-middle d-flex align-items-center"
                  >
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-facebook-f"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-instagram"></i
                    ></a>
                  </div>
                </div>
                <div class="text-center p-4 mt-3">
                  <h5 class="fw-bold mb-0">khaled Elbamby</h5>
                  <p> Back-end engineer</p>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
              <div class="team-item rounded overflow-hidden">
                <div class="position-relative">
                  <img class="img-fluid" src="img/ziad.jpg" alt="" />
                  <div
                    class="position-absolute start-50 top-100 translate-middle d-flex align-items-center"
                  >
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-facebook-f"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a class="btn btn-square mx-1" href=""
                      ><i class="fab fa-instagram"></i
                    ></a>
                  </div>
                </div>
                <div class="text-center p-4 mt-3">
                  <h5 class="fw-bold mb-0">Ziad Tamer</h5>
                  <p>FullStack developer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Team End -->

      <!-- Call to Action Start -->
      <div class="container-xxl py-5">
        <div class="container">
          <div class="bg-light rounded p-3">
            <div
              class="bg-white rounded p-4"
              style="border: 1px dashed rgba(0, 185, 142, 0.3)"
            >
              <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                  <img
                    class="img-fluid rounded w-100"
                    src="img/call-to-action.jpg"
                    alt=""
                  />
                </div>
                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                  <div class="mb-4">
                    <h1 class="mb-3">Contact With Our Certified Agent</h1>
                    <p>
                      Eirmod sed ipsum dolor sit rebum magna erat. Tempor lorem
                      kasd vero ipsum sit sit diam justo sed vero dolor duo.
                    </p>
                  </div>
                  <a href="" class="btn btn-primary py-3 px-4 me-2"
                    ><i class="fa fa-phone-alt me-2"></i>Make A Call</a
                  >
                  <a href="" class="btn btn-dark py-3 px-4"
                    ><i class="fa fa-calendar-alt me-2"></i>Get Appoinment</a
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Call to Action End -->

      <!-- Footer Start -->
      <div
        class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn"
        data-wow-delay="0.1s"
      >
        <div class="container py-5">
          <div class="row g-5">
            <div class="col-lg-3 col-md-6">
              <h5 class="text-white mb-4">Get In Touch</h5>
              <p class="mb-2">
                <i class="fa fa-map-marker-alt me-3"></i>123 Street, New York,
                USA
              </p>
              <p class="mb-2">
                <i class="fa fa-phone-alt me-3"></i>+012 345 67890
              </p>
              <p class="mb-2">
                <i class="fa fa-envelope me-3"></i>info@example.com
              </p>
              <div class="d-flex pt-2">
                <a class="btn btn-outline-light btn-social" href=""
                  ><i class="fab fa-twitter"></i
                ></a>
                <a class="btn btn-outline-light btn-social" href=""
                  ><i class="fab fa-facebook-f"></i
                ></a>
                <a class="btn btn-outline-light btn-social" href=""
                  ><i class="fab fa-youtube"></i
                ></a>
                <a class="btn btn-outline-light btn-social" href=""
                  ><i class="fab fa-linkedin-in"></i
                ></a>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <h5 class="text-white mb-4">Quick Links</h5>
              <a class="btn btn-link text-white-50" href="">About Us</a>
              <a class="btn btn-link text-white-50" href="">Contact Us</a>
              <a class="btn btn-link text-white-50" href="">Our Services</a>
              <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
              <a class="btn btn-link text-white-50" href=""
                >Terms & Condition</a
              >
            </div>
            <div class="col-lg-3 col-md-6">
              <h5 class="text-white mb-4">Photo Gallery</h5>
              <div class="row g-2 pt-2">
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-1.jpg"
                    alt=""
                  />
                </div>
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-2.jpg"
                    alt=""
                  />
                </div>
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-3.jpg"
                    alt=""
                  />
                </div>
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-4.jpg"
                    alt=""
                  />
                </div>
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-5.jpg"
                    alt=""
                  />
                </div>
                <div class="col-4">
                  <img
                    class="img-fluid rounded bg-light p-1"
                    src="img/property-6.jpg"
                    alt=""
                  />
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <h5 class="text-white mb-4">Newsletter</h5>
              <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
              <div class="position-relative mx-auto" style="max-width: 400px">
                <input
                  class="form-control bg-transparent w-100 py-3 ps-4 pe-5"
                  type="text"
                  placeholder="Your email"
                />
                <button
                  type="button"
                  class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2"
                >
                  SignUp
                </button>
              </div>
            </div>
          </div>
        </div>
        
      </div>
      <!-- Footer End -->

      <!-- Back to Top -->
      <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"
        ><i class="bi bi-arrow-up"></i
      ></a>
    </div>

   
</html>
<?php /**PATH C:\wamp64\www\real-estate\resources\views/property-agent.blade.php ENDPATH**/ ?>